package com.replica;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.server.ServerLifecycleHooks;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

@Mod(ReplicaMod.MOD_ID)
public class ReplicaMod {
    public static final String MOD_ID = "replica";

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MOD_ID);
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, MOD_ID);

    public static final RegistryObject<EntityType<ReplicaEntity>> REPLICA = ENTITIES.register("replica",
            () -> EntityType.Builder.of(ReplicaEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.95F)
                    .build(MOD_ID + ":replica"));

    public static final RegistryObject<SoundEvent> AMBIENT = sound("ambient");
    public static final RegistryObject<SoundEvent> CHASE = sound("chase");
    public static final RegistryObject<SoundEvent> STING = sound("sting");

    /** Sheep / cow / zombie shells that wear the disguise, mapped to their Replica. */
    static final Map<UUID, ReplicaEntity> SHELLS = new ConcurrentHashMap<>();
    /** The one Replica that is alive right now (null when none). */
    static ReplicaEntity active;

    static final String KIT_TAG = "replica_kit";
    static long nextSpawnAt = -1;

    private static RegistryObject<SoundEvent> sound(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(MOD_ID, name)));
    }

    public ReplicaMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ENTITIES.register(modBus);
        SOUNDS.register(modBus);
        modBus.addListener(this::onAttributes);
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onAttributes(EntityAttributeCreationEvent event) {
        event.put(REPLICA.get(), ReplicaEntity.createAttributes().build());
    }

    // ------------------------------------------------------------- schedule
    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null) return;

        long now = server.getTickCount();
        if (active != null && active.isRemoved()) {
            active = null;
            nextSpawnAt = -1;
        }
        if (nextSpawnAt < 0) nextSpawnAt = now + randomDelay();
        if (active == null && now >= nextSpawnAt) {
            if (!spawnRandom(server)) nextSpawnAt = now + 20L * 60L; // no safe spot or nobody online: retry in a minute
        }
    }

    /** 20 to 40 minutes, in ticks. */
    private static long randomDelay() {
        return ThreadLocalRandom.current().nextLong(20L * 60L * 20L, 40L * 60L * 20L + 1);
    }

    private static boolean spawnRandom(MinecraftServer server) {
        List<ServerPlayer> players = server.getPlayerList().getPlayers();
        if (players.isEmpty()) return false;
        ServerPlayer victim = players.get(ThreadLocalRandom.current().nextInt(players.size()));
        return spawnFor(victim);
    }

    static boolean spawnFor(ServerPlayer victim) {
        if (active != null && !active.isRemoved()) return false;
        ServerLevel level = (ServerLevel) victim.getCommandSenderWorld();
        var rnd = ThreadLocalRandom.current();

        double angle = rnd.nextDouble() * Math.PI * 2;
        double radius = 26 + rnd.nextDouble() * 8;
        int x = Mth.floor(victim.getX() + Math.cos(angle) * radius);
        int z = Mth.floor(victim.getZ() + Math.sin(angle) * radius);
        BlockPos surface = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING, new BlockPos(x, 0, z));

        ReplicaEntity spy = new ReplicaEntity(REPLICA.get(), level);
        spy.moveTo(x + 0.5, surface.getY(), z + 0.5, rnd.nextFloat() * 360F, 0F);
        level.addFreshEntity(spy);

        // disguise: a sheep, cow or zombie. In multiplayer it wears a friend's name, alone it wears yours.
        ReplicaEntity.Kind kind = ReplicaEntity.Kind.values()[rnd.nextInt(ReplicaEntity.Kind.values().length)];
        List<ServerPlayer> others = new ArrayList<>();
        for (ServerPlayer p : victim.getServer().getPlayerList().getPlayers()) {
            if (p != victim) others.add(p);
        }
        String name = others.isEmpty()
                ? victim.getName().getString()
                : others.get(rnd.nextInt(others.size())).getName().getString();

        spy.begin(victim, kind, name);
        active = spy;
        return true;
    }

    // ------------------------------------------------------------- elytra kit
    @SubscribeEvent
    public void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) giveKit(player);
    }

    static void giveKit(ServerPlayer player) {
        if (player.getTags().contains(KIT_TAG)) return;
        player.addTag(KIT_TAG);
        if (player.getItemBySlot(EquipmentSlot.CHEST).isEmpty()) {
            player.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.ELYTRA));
        } else {
            player.getInventory().add(new ItemStack(Items.ELYTRA));
        }
        for (int i = 0; i < 3; i++) {
            player.getInventory().add(new ItemStack(Items.FIREWORK_ROCKET, 64));
        }
        player.sendSystemMessage(Component.literal("§8Ek ajeeb si aawaz aayi... tumhare paas ek elytra aur fireworks aa gaye hain. Kaam aayenge."));
    }

    // ------------------------------------------------------------- damage
    @SubscribeEvent
    public void onAttack(LivingAttackEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity instanceof ReplicaEntity spy) {
            if (event.getSource().getEntity() instanceof ServerPlayer) spy.onPlayerAttacked();
            return;
        }
        ReplicaEntity owner = SHELLS.get(entity.getUUID());
        if (owner != null) {
            // hitting the sheep / cow / zombie shell reveals the real one and the shell takes no damage
            if (event.getSource().getEntity() instanceof ServerPlayer) owner.onPlayerAttacked();
            event.setCanceled(true);
        }
    }

    // ------------------------------------------------------------- commands
    @SubscribeEvent
    public void onCommands(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();
        dispatcher.register(Commands.literal("replica")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("spawn").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    if (spawnFor(p)) {
                        c.getSource().sendSuccess(() -> Component.literal("Replica spawned."), false);
                    } else {
                        c.getSource().sendFailure(Component.literal("Replica already active ya jagah nahi mili."));
                    }
                    return 1;
                }))
                .then(Commands.literal("reveal").executes(c -> {
                    if (active != null) active.reveal();
                    return 1;
                }))
                .then(Commands.literal("end").executes(c -> {
                    if (active != null) active.discard();
                    return 1;
                })));
    }
}
