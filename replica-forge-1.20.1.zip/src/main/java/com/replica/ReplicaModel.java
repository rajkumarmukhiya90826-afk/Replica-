package com.replica;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Replica's true form. An original hooded figure: tall, thin, arms too long, head slightly forward.
 * Units are 1/16 of a block, feet at y = 24. Total height is about 2.3 blocks.
 */
public class ReplicaModel extends EntityModel<ReplicaEntity> {

    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(ReplicaMod.MOD_ID, "replica"), "main");

    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart body;
    private final ModelPart armLeft;
    private final ModelPart armRight;
    private final ModelPart legLeft;
    private final ModelPart legRight;

    public ReplicaModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.body = root.getChild("body");
        this.armLeft = root.getChild("arm_left");
        this.armRight = root.getChild("arm_right");
        this.legLeft = root.getChild("leg_left");
        this.legRight = root.getChild("leg_right");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        // hood: 8 wide, 9 tall; the face (front) is the dark panel with the two red eyes
        root.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 0).addBox(-4F, -9F, -4F, 8F, 9F, 8F),
                PartPose.offset(0F, -4F, 0F));
        // long narrow robe
        root.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(16, 16).addBox(-3F, -4F, -2F, 6F, 14F, 4F),
                PartPose.offset(0F, 0F, 0F));
        // arms reach almost to the knees
        root.addOrReplaceChild("arm_left",
                CubeListBuilder.create().texOffs(40, 16).addBox(-1F, 0F, -1F, 2F, 16F, 2F),
                PartPose.offset(4.5F, -2F, 0F));
        root.addOrReplaceChild("arm_right",
                CubeListBuilder.create().texOffs(40, 16).addBox(-1F, 0F, -1F, 2F, 16F, 2F),
                PartPose.offset(-4.5F, -2F, 0F));
        // legs
        root.addOrReplaceChild("leg_left",
                CubeListBuilder.create().texOffs(0, 24).addBox(-1F, 0F, -1F, 2F, 14F, 2F),
                PartPose.offset(1.5F, 10F, 0F));
        root.addOrReplaceChild("leg_right",
                CubeListBuilder.create().texOffs(0, 24).addBox(-1F, 0F, -1F, 2F, 14F, 2F),
                PartPose.offset(-1.5F, 10F, 0F));

        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(ReplicaEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        // the head tracks the player, with a slow unsettling tilt
        head.yRot = netHeadYaw * Mth.DEG_TO_RAD;
        head.xRot = headPitch * Mth.DEG_TO_RAD + 0.12F;
        head.zRot = Mth.sin(ageInTicks * 0.05F) * 0.1F;

        // a lean forward, arms swinging slowly while walking
        body.xRot = 0.15F;
        armRight.xRot = Mth.cos(limbSwing * 0.6662F) * 1.2F * limbSwingAmount;
        armLeft.xRot = Mth.cos(limbSwing * 0.6662F + Mth.PI) * 1.2F * limbSwingAmount;
        legRight.xRot = Mth.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
        legLeft.xRot = Mth.cos(limbSwing * 0.6662F + Mth.PI) * 1.4F * limbSwingAmount;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
