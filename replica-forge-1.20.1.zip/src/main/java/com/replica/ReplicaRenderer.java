package com.replica;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class ReplicaRenderer extends MobRenderer<ReplicaEntity, ReplicaModel> {

    private static final ResourceLocation TEXTURE =
            new ResourceLocation(ReplicaMod.MOD_ID, "textures/entity/replica.png");

    public ReplicaRenderer(EntityRendererProvider.Context context) {
        super(context, new ReplicaModel(context.bakeLayer(ReplicaModel.LAYER)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(ReplicaEntity entity) {
        return TEXTURE;
    }
}
